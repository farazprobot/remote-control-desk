"""Run the owner Telegram bot and the public WebSocket relay together."""

from __future__ import annotations

import asyncio
import html
import logging
import os

from telegram import Update
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import BadRequest, InvalidToken
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)
from websockets.server import serve

from relay.key_store import KeyStore
from relay.server import Relay

LOG = logging.getLogger("control-bot")


def admin_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🖥  Active Devices", callback_data="admin_devices"),
            InlineKeyboardButton("🔑  Active Keys", callback_data="admin_keys"),
        ],
        [
            InlineKeyboardButton("🔐  New Master Key", callback_data="admin_new_master"),
            InlineKeyboardButton("🛰  New Agent Key", callback_data="admin_new_agent"),
        ],
        [InlineKeyboardButton("🔄  Refresh Dashboard", callback_data="admin_panel")],
    ])


def back_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️  Back to Main Panel", callback_data="admin_panel")]
    ])


def panel_text(active_devices: int, active_keys: int) -> str:
    return (
        "╭────────────────────────╮\n"
        "│  <b>REMOTE CONTROL DESK</b>  │\n"
        "│     <i>Owner Control Center</i>     │\n"
        "╰────────────────────────╯\n\n"
        "🟢 <b>Service Online</b>\n"
        "Secure owner-only management dashboard\n\n"
        "📡 <b>Live Overview</b>\n"
        f"   🖥 Connected devices: <b>{active_devices}</b>\n"
        f"   🔑 Active login keys: <b>{active_keys}</b>\n\n"
        "Choose an action below to manage your network.\n\n"
        "✦ <i>Developed by @Farazumar</i>"
    )


async def owner_view(
    update: Update,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    parse_mode: str | None = None,
) -> object | None:
    """Edit the existing admin message for button clicks."""
    query = update.callback_query
    if query and query.message:
        try:
            await query.message.edit_text(
                text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
            )
        except BadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                raise
        return query.message
    else:
        return await update.effective_message.reply_text(
            text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
        )


async def edit_saved_panel(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    parse_mode: str | None = None,
) -> None:
    """Edit the panel message after the owner submits a key name."""
    chat_id = context.user_data.get("admin_panel_chat_id")
    message_id = context.user_data.get("admin_panel_message_id")
    if not chat_id or not message_id:
        await owner_view(update, text, reply_markup, parse_mode)
        return
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
        )
    except BadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            raise


def owner_id() -> int:
    raw = os.environ.get("OWNER_TELEGRAM_ID") or os.environ.get("ADMIN_TELEGRAM_ID", "")
    if not raw.strip().lstrip("-").isdigit():
        raise RuntimeError("Set OWNER_TELEGRAM_ID to the owner's numeric Telegram ID")
    return int(raw.strip())


def is_owner(update: Update, allowed_id: int) -> bool:
    user = update.effective_user
    chat = update.effective_chat
    return bool(user and user.id == allowed_id and chat and chat.type == "private")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    allowed_id = context.application.bot_data["owner_id"]
    if is_owner(update, allowed_id):
        await update.effective_message.reply_text(
            "Remote Control Desk owner panel\n\n"
            "Master and Remote Agent keys are separate. "
            "Use the controls below or /panel.",
            reply_markup=admin_markup(),
        )
    else:
        await update.effective_message.reply_text(
            "This bot issues private session keys to its configured owner only."
        )


async def new_key(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    allowed_id = context.application.bot_data["owner_id"]
    if not is_owner(update, allowed_id):
        return
    await update.effective_message.reply_text(
        "Use /newmaster or /newagent. The bot will ask for the key name every time."
    )


async def begin_key_flow(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    role: str,
) -> None:
    if not is_owner(update, context.application.bot_data["owner_id"]):
        return
    role_name = "Master" if role == "master" else "Remote Agent"
    context.user_data["pending_key_role"] = role
    message = await owner_view(
        update,
        "╭────────────────────────╮\n"
        f"│  <b>NEW {role_name.upper()} KEY</b>  │\n"
        "╰────────────────────────╯\n\n"
        f"Enter a name for this {role_name} Login Key.\n"
        "Example: <i>Office Master</i> or <i>PC-01 Agent</i>\n\n"
        "Your next message will be used as the key name.",
        reply_markup=back_markup(),
        parse_mode="HTML",
    )
    if message:
        context.user_data["admin_panel_chat_id"] = message.chat_id
        context.user_data["admin_panel_message_id"] = message.message_id


async def key_name_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_owner(update, context.application.bot_data["owner_id"]):
        return
    role = context.user_data.get("pending_key_role")
    if role not in {"master", "agent"}:
        return
    label = (update.effective_message.text or "").strip()
    if not label:
        await edit_saved_panel(
            update,
            context,
            "Please send a name for the key. It cannot be empty.",
            back_markup(),
        )
        return

    store: KeyStore = context.application.bot_data["key_store"]
    key_id, raw_key = store.create(role, label[:80])
    role_name = "Master" if role == "master" else "Remote Agent"
    context.user_data.pop("pending_key_role", None)
    await edit_saved_panel(
        update,
        context,
        "╭────────────────────────╮\n"
        f"│  <b>{role_name.upper()} KEY CREATED</b>  │\n"
        "╰────────────────────────╯\n\n"
        f"🏷 Name: <b>{html.escape(label[:80])}</b>\n"
        f"🆔 Key ID: <b>#{key_id}</b>\n\n"
        f"🔐 <b>{html.escape(role_name)} Login Key</b>\n"
        f"<code>{raw_key}</code>\n\n"
        f"Enter this only in the {html.escape(role_name)} app. "
        "Never share it in a group or public chat.\n\n"
        "✦ <i>Developed by @Farazumar</i>",
        back_markup(),
        "HTML",
    )


async def issue_key(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    role: str,
    label: str = "",
) -> None:
    allowed_id = context.application.bot_data["owner_id"]
    if not is_owner(update, allowed_id):
        return
    store: KeyStore = context.application.bot_data["key_store"]
    label = label or ("Master PC" if role == "master" else "Remote Agent")
    key_id, raw_key = store.create(role, label)
    role_name = "Master" if role == "master" else "Remote Agent"
    await owner_view(
        update,
        f"{role_name} Login Key #{key_id} created ({html.escape(label)}).\n\n"
        f"<code>{raw_key}</code>\n\n"
        f"Enter this only in the {role_name} app. "
        "Never share a Master key with an Agent or vice versa.",
        parse_mode="HTML",
        reply_markup=back_markup(),
    )


async def new_master(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await begin_key_flow(update, context, "master")


async def new_agent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await begin_key_flow(update, context, "agent")


async def panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_owner(update, context.application.bot_data["owner_id"]):
        return
    context.user_data.pop("pending_key_role", None)
    store: KeyStore = context.application.bot_data["key_store"]
    relay: Relay = context.application.bot_data["relay"]
    active_keys = sum(1 for row in store.list_keys() if not row["revoked_at"])
    message = await owner_view(
        update,
        panel_text(len(relay.active_devices()), active_keys),
        reply_markup=admin_markup(),
        parse_mode="HTML",
    )
    if message:
        context.user_data["admin_panel_chat_id"] = message.chat_id
        context.user_data["admin_panel_message_id"] = message.message_id


async def list_keys(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    allowed_id = context.application.bot_data["owner_id"]
    if not is_owner(update, allowed_id):
        return
    store: KeyStore = context.application.bot_data["key_store"]
    rows = [row for row in store.list_keys() if not row["revoked_at"]]
    if not rows:
        await owner_view(
            update,
            "No active login keys have been issued.",
            reply_markup=admin_markup(),
        )
        return
    lines = ["Active login keys:"]
    counts = context.application.bot_data["relay"].active_key_counts()
    for row in rows:
        label = row["label"] or "Desktop session"
        role = "Master" if row["role"] == "master" else "Remote Agent"
        lines.append(
            f"#{row['id']} — {role} — {label} — "
            f"{counts.get(row['id'], 0)} connected — {row['created_at']} UTC"
        )
    buttons = [
        [InlineKeyboardButton(f"Revoke #{row['id']}", callback_data=f"admin_revoke_{row['id']}")]
        for row in rows[:20]
    ]
    buttons.append([InlineKeyboardButton("⬅️  Back to Main Panel", callback_data="admin_panel")])
    await owner_view(
        update,
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def revoke_key(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    allowed_id = context.application.bot_data["owner_id"]
    if not is_owner(update, allowed_id):
        return
    if len(context.args) != 1 or not context.args[0].isdigit():
        await update.effective_message.reply_text("Usage: /revoke <key_id>")
        return
    store: KeyStore = context.application.bot_data["key_store"]
    key_id = int(context.args[0])
    if store.revoke(key_id):
        disconnected = await context.application.bot_data["relay"].disconnect_key(key_id)
        await update.effective_message.reply_text(
            f"Session key #{key_id} revoked. Disconnected devices: {disconnected}."
        )
    else:
        await update.effective_message.reply_text("Key not found or already revoked.")


async def admin_devices(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_owner(update, context.application.bot_data["owner_id"]):
        return
    relay: Relay = context.application.bot_data["relay"]
    devices = relay.active_devices()
    if not devices:
        text = "🖥 Active Devices\n\nNo Master or Remote Agent devices are connected."
    else:
        lines = [f"🖥 Active Devices — {len(devices)} connected\n"]
        for device in devices:
            role = "Master" if device["role"] == "master" else "Remote Agent"
            lines.append(
                f"• {role}: {device['name']}\n"
                f"  ID: <code>{device['client_id']}</code>\n"
                f"  Login key: #{device['key_id']} | "
                f"Connected: {device['connected_seconds']}s | "
                f"Sessions: {device['sessions']}"
            )
        text = "\n".join(lines)
    await owner_view(
        update,
        text,
        parse_mode="HTML",
        reply_markup=back_markup(),
    )


async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not is_owner(update, context.application.bot_data["owner_id"]):
        return
    action = str(query.data or "")
    if action == "admin_devices":
        await admin_devices(update, context)
    elif action == "admin_keys":
        await list_keys(update, context)
    elif action == "admin_new_master":
        await begin_key_flow(update, context, "master")
    elif action == "admin_new_agent":
        await begin_key_flow(update, context, "agent")
    elif action.startswith("admin_revoke_"):
        key_id_text = action.removeprefix("admin_revoke_")
        if key_id_text.isdigit():
            key_id = int(key_id_text)
            store: KeyStore = context.application.bot_data["key_store"]
            if store.revoke(key_id):
                disconnected = await context.application.bot_data["relay"].disconnect_key(key_id)
                await owner_view(
                    update,
                    f"Session key #{key_id} revoked. Disconnected devices: {disconnected}.",
                    reply_markup=admin_markup(),
                )
            else:
                await owner_view(
                    update,
                    "Key not found or already revoked.",
                    reply_markup=admin_markup(),
                )
    elif action == "admin_panel":
        await panel(update, context)


async def main() -> None:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    # httpx includes the Telegram API URL in INFO logs, and that URL contains
    # the bot token. Keep transport logs quiet so credentials never reach logs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("Set BOT_TOKEN to run the Telegram owner bot")
    allowed_id = owner_id()
    store = KeyStore()
    relay = Relay(store)
    app = Application.builder().token(token).build()
    app.bot_data["owner_id"] = allowed_id
    app.bot_data["key_store"] = store
    app.bot_data["relay"] = relay
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("panel", panel))
    app.add_handler(CommandHandler("newkey", new_key))
    app.add_handler(CommandHandler("key", new_key))
    app.add_handler(CommandHandler("newmaster", new_master))
    app.add_handler(CommandHandler("newagent", new_agent))
    app.add_handler(CommandHandler("keys", list_keys))
    app.add_handler(CommandHandler("revoke", revoke_key))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern=r"^admin_"))
    app.add_handler(
        MessageHandler(
            filters.TEXT & filters.ChatType.PRIVATE & ~filters.COMMAND,
            key_name_text,
        )
    )

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8765"))
    LOG.info("Starting owner bot and relay on %s:%s", host, port)
    async with serve(relay.handle, host, port, max_size=8 * 1024 * 1024, ping_interval=20):
        try:
            await app.initialize()
        except InvalidToken:
            LOG.error("Telegram rejected BOT_TOKEN. Replace it in Replit Secrets.")
            await app.shutdown()
            return
        await app.start()
        await app.updater.start_polling()
        try:
            await asyncio.Future()
        finally:
            await app.updater.stop()
            await app.stop()
            await app.shutdown()


if __name__ == "__main__":
    asyncio.run(main())